hold off;
hold on;
scatter(matA(:,1),matA(:,2), 'blue');
scatter(matB(:,1),matB(:,2), 'red', 'filled');
xlabel('x'); ylabel('y'); legend('Set A', 'Set B');